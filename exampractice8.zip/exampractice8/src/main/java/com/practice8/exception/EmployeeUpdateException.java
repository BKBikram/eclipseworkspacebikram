package com.practice8.exception;

public class EmployeeUpdateException extends Exception{

	
	private static final long serialVersionUID = 1L;

	public EmployeeUpdateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeUpdateException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EmployeeUpdateException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeUpdateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmployeeUpdateException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
