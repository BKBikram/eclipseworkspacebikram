package com.practice8.repository.specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.data.jpa.domain.Specification;

import com.practice8.entity.Employee;

public class EmployeeSpecification {
	public static Specification<Employee> getEmployee(String searchParam){
		return new Specification<Employee>() {

			@Override
			public Predicate toPredicate(Root<Employee> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate finalPredicate=null;
				JSONParser parser=new JSONParser();
				try {
//					JSONObject obj=(JSONObject) parser.parse(searchParam);
//					String field1=(String) obj.get("field1");
//					String field2=(String) obj.get("field2");
					if(!searchParam.isEmpty()) {
						Predicate field1Predicate=criteriaBuilder.equal(root.get("firstName"), searchParam);
						finalPredicate=criteriaBuilder.and(field1Predicate);
					}
//					if(!searchParam.isEmpty()) {
//						Predicate field2Predicate=criteriaBuilder.equal(root.get("lastName"), searchParam);
//						if(finalPredicate!=null) {
//							finalPredicate=criteriaBuilder.and(finalPredicate,field2Predicate);
//						}else {
//							finalPredicate=criteriaBuilder.and(field2Predicate);
//						}
//				} 
				}catch (Exception e) {
					//only for logger
					}
				return finalPredicate;
			}
		};
		
		
	}

}
